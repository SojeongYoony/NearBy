package com.koreait.nearby.service;

public class FollowServiceImpl implements FollowService {

}
