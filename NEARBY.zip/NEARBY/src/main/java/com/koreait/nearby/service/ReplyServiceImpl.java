package com.koreait.nearby.service;

public class ReplyServiceImpl implements ReplyService {

}
