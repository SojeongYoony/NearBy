package com.koreait.nearby.service;

public class ProfileServiceImpl implements ProfileService {

}
