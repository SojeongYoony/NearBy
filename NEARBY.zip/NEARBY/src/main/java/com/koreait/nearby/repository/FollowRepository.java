package com.koreait.nearby.repository;

public interface FollowRepository {

}
