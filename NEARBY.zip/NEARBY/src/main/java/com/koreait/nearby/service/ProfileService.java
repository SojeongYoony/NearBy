package com.koreait.nearby.service;

public interface ProfileService {

}
